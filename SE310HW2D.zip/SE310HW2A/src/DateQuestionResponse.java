import java.time.LocalDate;
import java.util.Scanner;

public class DateQuestionResponse extends Response{
    private LocalDate response;
    public DateQuestionResponse(LocalDate date, int questionNumber){
        super(questionNumber);
        this.response = date;
    }

    public void setResponse(LocalDate response) {
        this.response = response;
    }
    public LocalDate getResponse(){
        return this.response;
    }

    @Override
    public void display() {
        System.out.println(this.response);
    }

    @Override
    public Boolean isEqual(Response response) {
        if (response instanceof DateQuestionResponse){
            DateQuestionResponse correctAnswer = (DateQuestionResponse) response;
            return correctAnswer.getResponse().equals(this.getResponse());
        } else {
            return false;
        }
    }
}
