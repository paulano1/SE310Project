import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class DateQuestionCommandLineRenderer implements CommandLineRenderer<LocalDate, String>, Serializable {
    private static final String SEPARATOR = "--------------------------";
    private static final String OPENING = "-----Date Question------";
    private static final long serialVersionUID = 1L;

    @Override
    public void displayQuestion(String prompt) {
        System.out.println(OPENING);
        System.out.println(prompt);

    }

    @Override
    public void displayResponse(LocalDate response) {
        System.out.println(SEPARATOR);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        if (response != null) {
            System.out.println("User response: " + response.format(formatter));
        } else {
            System.out.println("No response was provided.");
        }
    }

    @Override
    public LocalDate getResponse(String prompt, Scanner scanner) {
        LocalDate date = null;
        boolean valid = false;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        while (!valid) {
            try {
                String input = scanner.nextLine();
                date = LocalDate.parse(input, formatter);
                valid = true;
            } catch (DateTimeParseException e) {
                System.err.println("Invalid date format. Please use the YYYY-MM-DD format.");
            }
        }

        return date;
    }

    @Override
    public String modifyQuestion(String prompt, Scanner scanner) {
        String newPrompt;

        while (true) {
            System.out.println("Enter new prompt: ");
            System.out.println(prompt);
            newPrompt = scanner.nextLine();
            if (!newPrompt.trim().isEmpty()) {
                break;
            }
            System.out.println("The prompt cannot be empty. Please enter a valid prompt.");
        }

        return newPrompt;
    }

}
