import java.util.ArrayList;

public class ShortAnswerResponse extends EssayQuestionResponse{
    public ShortAnswerResponse(ArrayList<String> response, int questionNumber) {
        super(response, questionNumber);
    }
    @Override
    public Boolean isEqual(Response response) {
        if (response instanceof ShortAnswerResponse){
            ShortAnswerResponse correctAnswer = (ShortAnswerResponse) response;
            return correctAnswer.getResponse().equals(this.getResponse());
        } else {
            return false;
        }
    }
}
