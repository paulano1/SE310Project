import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class MultipleChoiceQuestionCommandLineRenderer implements CommandLineRenderer<ArrayList<String>, ArrayList<String>>, Serializable {
    private static final String SEPARATOR = "--------------------------";
    private static final String OPENING = "--Multiple choice Question-";
    private static final long serialVersionUID = 1L;
    @Override
    public void displayQuestion(ArrayList<String> prompt) {
        System.out.println(OPENING);
        System.out.println("Question: " + prompt.get(0));

        StringBuilder choices = new StringBuilder();
        for (int i = 1; i < prompt.size(); i++) {
            char choiceLabel = (char) ('a' + i - 1);
            choices.append(choiceLabel).append(") ").append(prompt.get(i)).append("\n");
        }

        System.out.println(choices);
    }

    public void displayResponse(ArrayList<String> response) {
        System.out.println(SEPARATOR);
        if (response == null) {
            System.out.println("User response: No response");
            return;
        }
        System.out.println("User response:");
        for (int i = 0; i < response.size(); i++) {
            char choiceLabel = (char) ('A' + i);
            System.out.println(choiceLabel + ") " + response.get(i));
        }
    }

    public ArrayList<String> getResponse(ArrayList<String> prompt, Scanner scanner) {
        System.out.println(SEPARATOR);
        ArrayList<String> responses = new ArrayList<>();
        HashSet<String> addedResponses = new HashSet<>();
        String input;


        System.out.println("Please enter your choices one by one:");
        System.out.println("Enter 'done' when you have finished making your choices.");
        while (true) {
            System.out.println("Enter your choice (" + 'A' + " to " + (char) ('A' + prompt.size() - 1) + ", or 'done'):");
            input = scanner.nextLine().trim().toUpperCase();
            if ("DONE".equalsIgnoreCase(input)) {
                if (responses.isEmpty()) {
                    System.out.println("No choices have been made. Please enter at least one choice.");
                    continue;
                } else {
                    break;
                }
            }
            if (input.length() == 1 && input.charAt(0) >= 'A' && input.charAt(0) < 'A' + prompt.size()) {
                int index = input.charAt(0) - 'A';
                String choice = prompt.get(index);
                if (addedResponses.contains(choice)) {
                    System.out.println("You have already selected this option. Please choose a different one.");
                } else {
                    responses.add(input);
                    addedResponses.add(choice);
                }
            } else {
                System.out.println("Invalid choice. Please enter a letter corresponding to one of the options, or 'done'.");
            }
        }
        return responses;
    }


    public ArrayList<String> modifyQuestion(ArrayList<String> prompt, Scanner scanner) {
        String newPrompt;
        ArrayList<String> newChoices = new ArrayList<>();

        // Get the new prompt
        do {
            System.out.println("Current Prompt: " + prompt.get(0));
            System.out.println("Enter new prompt:");
            newPrompt = scanner.nextLine().trim();
            if (newPrompt.isEmpty()) {
                System.out.println("Prompt cannot be empty.");
            }
        } while (newPrompt.isEmpty());

        newChoices.add(newPrompt);

        // Get the new choices
        String input;
        for (int i = 1; i < prompt.size(); i++) {
            System.out.println("Current choice #" + i + ":  " + prompt.get(i));
            System.out.println("Enter new choice for #" + i + ":");
            input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                newChoices.add(input);
            } else {
                System.out.println("Choice cannot be empty. Please enter a valid choice.");
                i--;
            }
        }

        String additional;
        do {
            System.out.println("Do you want to add more options? (Y/N)");
            additional = scanner.nextLine().trim().toUpperCase();
            if (!additional.equalsIgnoreCase("y") && !additional.equalsIgnoreCase("n")) {
                System.out.println("Invalid response. Please enter 'Y' for Yes or 'N' for No.");
            }
        } while (!additional.equals("Y") && !additional.equals("N"));

        if (additional.equals("Y")) {
            int additionalCount;
            do {
                System.out.println("How many more options do you want to add?");
                while (!scanner.hasNextInt()) {
                    System.out.println("That's not a number. Please enter a valid number.");
                    scanner.next();
                }
                additionalCount = scanner.nextInt();
                scanner.nextLine(); // consume the newline after the number
                if (additionalCount <= 0) {
                    System.out.println("Please enter a positive number.");
                }
            } while (additionalCount <= 0);

            for (int i = 0; i < additionalCount; i++) {
                System.out.println("Enter additional choice #" + (i + 1) + ":");
                input = scanner.nextLine().trim();
                if (!input.isEmpty()) {
                    newChoices.add(input);
                } else {
                    System.out.println("Choice cannot be empty. Please enter a valid choice.");
                    i--;
                }
            }
        }
        return newChoices;
    }

}
