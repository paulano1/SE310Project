import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

public class SurveyFactory {

    public static final String RESPONSE_PREFIX = "response";
    public static final String SURVEY_PREFIX = "survey";
    MatchingQuestionFactory matchingQuestionFactory;
    MultipleChoiceQuestionFactory multipleChoiceQuestionFactory;
    TrueFalseQuestionFactory trueFalseQuestionFactory;
    DateQuestionFactory dateQuestionFactory;
    ShortAnswerQuestionFactory shortAnswerQuestionFactory;
    EssayQuestionFactory essayQuestionFactory;
    Scanner scanner;
    public static final String surveyDirectory = "surveys";
    String responsesDirectory = "responses";
    protected FileManager fileManager;
    public SurveyFactory(Scanner scanner){
        this.scanner = scanner;
        matchingQuestionFactory = new MatchingQuestionFactory();
        multipleChoiceQuestionFactory = new MultipleChoiceQuestionFactory();
        trueFalseQuestionFactory = new TrueFalseQuestionFactory();
        shortAnswerQuestionFactory = new ShortAnswerQuestionFactory();
        essayQuestionFactory = new EssayQuestionFactory();
        dateQuestionFactory = new DateQuestionFactory();

        fileManager = FileManager.getInstance();
    }

    protected Boolean surveyNotSaved(Survey survey){
        return survey.getCurrentFileName() == null && survey.getSurvey() != null;
    }

    protected Boolean continueQuestion(Scanner scanner){
        String input;
        while (true) {

            System.out.println("current survey is not saved, Do you want to continue? (Y/N)");
            input = scanner.nextLine().trim();
            if ("yes".equalsIgnoreCase(input) || "y".equalsIgnoreCase(input)) {
                return true;
            } else if ("no".equalsIgnoreCase(input) || "n".equalsIgnoreCase(input)) {
                return false;
            } else {
                System.out.println("Invalid input. Only 'Yes' or 'No' is accepted."); // Prompt again if input is not valid
            }
        }
    }
    protected void createQuestionMenu(){
        System.out.println("\n--- Add Question Menu ---");
        System.out.println("1) Add a new T/F question");
        System.out.println("2) Add a new multiple-choice question");
        System.out.println("3) Add a new short answer question");
        System.out.println("4) Add a new essay question");
        System.out.println("5) Add a new date question");
        System.out.println("6) Add a new matching question");
        System.out.println("7) Return to previous menu");
        System.out.print("Enter an option: ");
    }

    public void loadExistingSurvey(Survey survey, String directory, String filePrefix){
        if (surveyNotSaved(survey)){
            if (!continueQuestion(scanner)){
                return;
            }
        }

        ArrayList<Question> loadedQuestions = null;
        List<String> surveyFiles = fileManager.listSurveyFiles(directory, filePrefix);

        if (surveyFiles == null || surveyFiles.isEmpty()) {
            System.out.println("No surveys available to load.");
            return;
        }

        System.out.println("\n--- Available Surveys ---");
        for (int i = 0; i < surveyFiles.size(); i++) {
            System.out.println((i + 1) + ") " + surveyFiles.get(i).split("\\\\")[1]);
        }
        System.out.print("Enter the number of the survey you want to load: ");

        int fileChoice = -1;
        boolean validChoice = false;

        while (!validChoice) {
            System.out.print("Enter the number of the survey you want to load: ");

            try {
                fileChoice = Integer.parseInt(scanner.nextLine());
                if (fileChoice >= 1 && fileChoice <= surveyFiles.size()) {
                    validChoice = true;
                } else {
                    System.out.println("Invalid choice. Please select a number from the list.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }

        String selectedFile = surveyFiles.get(fileChoice - 1);
        try {
            loadedQuestions = fileManager.loadQuestions(selectedFile);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading the survey: " + e.getMessage());
        } finally {
            survey.setSurvey(loadedQuestions);
            survey.setCurrentFileName(selectedFile);
        }
    }
    public void createSurvey(Survey survey) {
        if (surveyNotSaved(survey)){
            if (!continueQuestion(scanner)){
                return;
            }
        }
        survey.setCurrentFileName(null);

        ArrayList<Question> questions = new ArrayList<>();
        int option = 0;
        do {
            createQuestionMenu();
            try {
                option = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
                continue;
            }
            switch (option) {
                case 1:
                    questions.add(trueFalseQuestionFactory.createQuestion(scanner));
                    break;
                case 2:
                    questions.add(multipleChoiceQuestionFactory.createQuestion(scanner));
                    break;
                case 3:
                    questions.add(shortAnswerQuestionFactory.createQuestion(scanner));
                    break;
                case 4:
                    questions.add(essayQuestionFactory.createQuestion(scanner));
                    break;
                case 5:
                    questions.add(dateQuestionFactory.createQuestion(scanner));
                    break;
                case 6:
                    questions.add(matchingQuestionFactory.createQuestion(scanner));
                    break;
                case 7:
                    System.out.println("Returning to previous menu...");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (option != 7);
        if (!questions.isEmpty()) {
            survey.setSurvey(questions);
        } else {
            survey.setSurvey(null);
        }
    }

    public void saveSurvey(Survey survey){
        ArrayList<Question> questions = survey.getSurvey();
        if (questions == null){
            System.out.println("Create a survey to save");
            return;
        }
        String pathName = fileManager.saveQuestionnaire(questions, surveyDirectory, SURVEY_PREFIX);
        survey.setSurvey(null);
        survey.setCurrentFileName(null);
    }

    public void takeSurvey(Survey survey, Scanner scanner, String directory, String filePrefix) {
        if (surveyNotSaved(survey)){
            System.out.println("Please save your existing file before loading a different survey");
            return;
        }
        loadExistingSurvey(survey, directory, filePrefix);
        if (survey.getSurvey() == null){
            return;
        }
        SurveyResponses responses = survey.respond(scanner);
        responses.setSurveyFileName(survey.getCurrentFileName());
        if(!fileManager.saveQuestionnaireResponse(responses, RESPONSE_PREFIX)){
            System.out.println("Survey could not be saved, try again");
        }
    }

    public void modifyQuestion(Survey survey, Scanner scanner) {
        if (survey.getSurvey() == null || survey.getSurvey().isEmpty()) {
            System.out.println("Please load a survey to modify.");
            return;
        }

        ArrayList<Question> questions = survey.getSurvey();
        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            q.displayPrompt();

            System.out.println("Do you want to modify this Question? (Y/N)");
            String response = scanner.nextLine().trim().toUpperCase();

            if ("y".equalsIgnoreCase(response)) {
                q.modify(scanner);
            } else if (!"n".equalsIgnoreCase(response)) {
                System.out.println("Invalid input. Please enter 'Y' for Yes or 'N' for No.");
                i--;
            }
        }
        fileManager.saveObjectStaticPath(survey.getSurvey(), survey.getCurrentFileName());
    }

    public void displayQuestions(Survey survey) {
        if (survey.getSurvey() == null || survey.getSurvey().isEmpty()){
            System.out.println("You must have a survey loaded in order to display it.");
        }else {
            System.out.println("Filename: "+ survey.getCurrentFileName());
            survey.displayQuestions();
        }
    }

    public void tabulateSurvey(Survey survey){
        boolean condition = (survey.getCurrentFileName() == null || survey.getCurrentFileName().isEmpty()) || survey.getSurvey() == null;
        if (condition){
            System.out.println("Survey not saved, hence no responses");
            return;
        }
        ArrayList<SurveyResponses> responses = fileManager.getAllResponses(survey.getCurrentFileName());
        if (responses == null){
            System.out.println("no responses to tabulate");
            return;
        }
        int numberOfQuestions = responses.get(0).getSize();
        System.out.println("--------TABULATION--------");
        for (int i = 0; i < numberOfQuestions; i++) {
            Question question = survey.getSurvey().get(i);

            switch (question.questionType.toLowerCase()) {
                case "truefalse":
                    question.displayPrompt();
                    int numberOfTrue = 0;
                    int numberOfFalse = 0;
                    for (SurveyResponses surveyResponses : responses) {
                        TrueFalseQuestionResponse currentResponse = (TrueFalseQuestionResponse) surveyResponses.getByIndex(i);
                        if (currentResponse.getResponse().equals(true)){
                            numberOfTrue += 1;
                        } else {
                            numberOfFalse += 1;
                        }
                    }
                    System.out.println("Tabulation: ");
                    System.out.println("True: " + numberOfTrue);
                    System.out.println("False: " + numberOfFalse);
                    break;

                case "multiplechoice":
                    MultipleChoiceQuestion multQuestion = (MultipleChoiceQuestion) question;
                    multQuestion.displayPrompt();
                    int numberOfChoices = multQuestion.getNumberOfChoices();

                    LinkedHashMap<String, Integer> map = new LinkedHashMap<>();
                    for (char key = 'A'; key < 'A' + numberOfChoices; key++) {
                        map.put(String.valueOf(key), 0);
                    }

                    System.out.println("Tabulation: ");
                    for (SurveyResponses surveyResponses : responses) {
                        MultipleChoiceResponse currentResponse = (MultipleChoiceResponse) surveyResponses.getByIndex(i);
                        for (String choice : currentResponse.getResponse()) {
                            map.put(choice, map.getOrDefault(choice, 0) + 1);
                        }
                    }

                    map.forEach((key, value) -> System.out.println(key + ": " + value));
                    break;

                case "shortanswer":
                    question.displayPrompt();
                    HashMap<String, Integer> choiceSet = new HashMap<>();

                    for (SurveyResponses surveyResponses : responses) {
                        ShortAnswerResponse currentResponse = (ShortAnswerResponse) surveyResponses.getByIndex(i);
                        for (String choice : currentResponse.getResponse()) {
                            choiceSet.put(choice, choiceSet.getOrDefault(choice, 0) + 1);
                        }
                    }
                    System.out.println("Tabulation: ");
                    choiceSet.forEach((key, value) -> System.out.println(key + ": " + value));
                    break;

                case "essay":
                    question.displayPrompt();
                    int j = 1;
                    for (SurveyResponses surveyResponses : responses) {
                        System.out.println("Response " + j + " :");
                        System.out.println(surveyResponses.getClass());
                        EssayQuestionResponse currentResponse = (EssayQuestionResponse) surveyResponses.getByIndex(i);
                        currentResponse.display();
                        j +=  1;
                    }
                    break;

                case "datequestion":
                    question.displayPrompt();
                    HashMap<LocalDate, Integer> dateMap = new HashMap<>();

                    for (SurveyResponses surveyResponses : responses) {
                        DateQuestionResponse currentResponse = (DateQuestionResponse) surveyResponses.getByIndex(i);
                        dateMap.put(currentResponse.getResponse(), dateMap.getOrDefault(currentResponse.getResponse(), 0) + 1);

                    }
                    System.out.println("Tabulation: ");
                    dateMap.forEach((key, value) -> System.out.println(key + ": \n" + value));
                    break;

                case "matching":
                    question.displayPrompt();
                    HashMap<HashSet<String>, Integer> matchChoices = new HashMap<>();

                    for (SurveyResponses surveyResponse : responses) {
                        MatchingQuestionResponse currentResponse = (MatchingQuestionResponse) surveyResponse.getByIndex(i);
                        HashSet<String> tempSet = new HashSet<>(currentResponse.getResponse());
                        matchChoices.put(tempSet, matchChoices.getOrDefault(new HashSet<>(currentResponse.getResponse()), 0) + 1);
                    }
                    System.out.println("Tabulation: ");
                    matchChoices.forEach((key, value) -> {
                        System.out.println("\n" + value );
                        for (String choice:
                             key) {
                            System.out.println(choice);
                        }

                    });
                    break;
                default:
                    break;
            }

        }

    }
}
