import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.CompletableFuture;


public class Main {
    private final Scanner scanner;
    private final Survey survey;
    private Test test;
    private TestFactory testFactory;

    private final SurveyFactory surveyFactory;

    public Main(Scanner scanner) {
        this.scanner = scanner;
        this.survey = new Survey();
        this.surveyFactory = new SurveyFactory(this.scanner);
        this.test = new Test();
        this.testFactory = new TestFactory(scanner);
    }

    private void displayMainMenu(){
        System.out.println("1) Survey");
        System.out.println("2) Test");
        System.out.println("3) Exit");
    }

    private void displayTestMenu(){
        System.out.println("1) Create a new Test\n" +
                "2) Display an existing Test without correct answers\n" +
                "3) Display an existing Test with correct answers\n" +
                "4) Load an existing Test\n" +
                "5) Save the current Test\n" +
                "6) Take the current Test\n" +
                "7) Modify the current Test\n" +
                "8) Tabulate a Test\n" +
                "9) Grade a Test\n" +
                "10) Return to the previous menu");
    }

    private void displaySurveyMenu() {
        System.out.println("1) Create a new Survey\n" +
                "2) Display an existing Survey\n" +
                "3) Load an existing Survey\n" +
                "4) Save the current Survey\n" +
                "5) Take the current Survey\n" +
                "6) Modify the current Survey\n" +
                "7) Tabulate a survey\n" +
                "8) Return to previous menu");
    }
    private int validInteger(){
        boolean flag = true;
        int option = 0;
        while (flag){
            try {
                option = Integer.parseInt(scanner.nextLine());
                flag = false;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
        return option;
    }
    public void mainMenu(){
        int option = 0;
        do {
            displayMainMenu();
            option = validInteger();
            switch (option){
                case 1:
                    surveyMenu();
                    break;
                case 2:
                    testMenu();
                    break;
                case 3:
                    System.out.println("Exiting gracefully.....");
                    break;
                default:
                    System.out.println("invalid choice");
            }
        } while (option != 3);
    }

    private void testMenu() {
        int option = 0;
        do {
            displayTestMenu();
            option = validInteger();

            switch (option) {
                case 1:
                    testFactory.createTest(test);
                    break;
                case 2:
                    testFactory.displayTestWithoutAnswers(test);
                    break;
                case 3:
                    testFactory.displayTest(test);
                    break;
                case 4:
                    testFactory.loadTest(test);
                    break;
                case 5:
                    testFactory.saveTest(test);
                    break;
                case 6:
                    testFactory.takeTest(scanner, test);
                    break;
                case 7:
                    testFactory.modifyTest(scanner, test);
                    break;
                case 8:
                    testFactory.tabulateSurvey(test);
                    break;
                case 9:
                    testFactory.grade(test);
                    break;
                case 10:
                    System.out.println("Returning to previous menu......");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (option != 10);
    }


    public void surveyMenu(){

        int option = 0;
        do {
            displaySurveyMenu();
            option = validInteger();

            switch (option) {
                case 1:
                    surveyFactory.createSurvey(survey);
                    break;
                case 2:
                    surveyFactory.displayQuestions(survey);
                    break;
                case 3:
                    surveyFactory.loadExistingSurvey(survey, SurveyFactory.surveyDirectory, SurveyFactory.SURVEY_PREFIX);
                    break;
                case 4:
                    surveyFactory.saveSurvey(survey);
                    break;
                case 5:
                    surveyFactory.takeSurvey(survey, scanner, SurveyFactory.surveyDirectory, SurveyFactory.surveyDirectory);
                    break;
                case 6:
                    surveyFactory.modifyQuestion(survey, scanner);
                    break;
                case 7:
                    surveyFactory.tabulateSurvey(survey);
                    break;
                case 8:
                    System.out.println("Returning to previous menu......");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (option != 8);

    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Main main = new Main(scanner);
        main.mainMenu();
        scanner.close();
    }

}