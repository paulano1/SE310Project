public class EssayQuestionCommandLineRenderer extends ShortAnswerQuestionCommandLineRenderer{
    public EssayQuestionCommandLineRenderer(){
        super("-----Essay Question------");
    }
}
