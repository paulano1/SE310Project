import java.util.ArrayList;

public class Test extends Survey{
    TestCorrectAnswers correctAnswer;
    SurveyResponses testResponse;
    public Test(){
        correctAnswer = null;
        testResponse = null;
    }

    public void setTest(ArrayList<Question> questions, ArrayList<Response> correctAnswer) {
        super.setSurvey(questions);
        this.correctAnswer = new TestCorrectAnswers(correctAnswer, null);
    }

    public void displayTest(){
        if (this.questions == null || correctAnswer == null ){
            System.out.println("You must have a test loaded in order to display it.");
        } else {
            for (int i = 0; i < this.questions.size(); i++) {
                questions.get(i).displayPrompt();
                System.out.println("--Correct Answer--");
                correctAnswer.getUserResponses().get(i).display();
            }
        }
    }
    public void setCorrectAnswerFilePath(String filePath){
        correctAnswer.setSurveyFileName(filePath);
    }

    public TestCorrectAnswers getCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(TestCorrectAnswers testCorrectAnswers){
        this.correctAnswer = testCorrectAnswers;
    }
    public Boolean testSaved(){
        return getCurrentFileName() != null;
    }

}
