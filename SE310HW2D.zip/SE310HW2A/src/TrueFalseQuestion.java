import java.util.Scanner;

public class TrueFalseQuestion extends Question{
    Boolean response;
    CommandLineRenderer<Boolean,String> render;

    public TrueFalseQuestion(String prompt, TrueFalseQuestionCommandLineRenderer render){
        super(prompt, "trueFalse");
        this.render = render;

    }

    @Override
    public void displayPrompt() {
        render.displayQuestion(prompt);
    }

    @Override
    public void displayResponse() {
        this.render.displayResponse(response);
    }

    @Override
    public Response respond(Scanner scanner, int questionNumber) {
        Boolean tempResponse = render.getResponse(prompt, scanner);
        return new TrueFalseQuestionResponse(tempResponse, questionNumber);
    }

    @Override
    public void modify(Scanner scanner) {
            prompt = render.modifyQuestion(prompt, scanner);
    }
}
