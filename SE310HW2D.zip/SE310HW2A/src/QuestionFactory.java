import java.util.Scanner;

public interface QuestionFactory <T>{
    T createQuestion(Scanner scanner);
}
