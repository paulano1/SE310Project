import java.util.Scanner;

public class DateQuestionFactory implements QuestionFactory<DateQuestion>{
    private static final String SEPARATOR = "--------------------------";
    private static final String OPENING = "-- Date Question --";
    private static final String PROMPT_INSTRUCTION = "Enter your prompt (cannot be empty):";
    private static final String ERROR_EMPTY_INPUT = "Input cannot be empty. Please try again.";
    @Override
    public DateQuestion createQuestion(Scanner scanner) {
        String prompt;
        System.out.println(OPENING);
        do {
            System.out.println(PROMPT_INSTRUCTION);
            prompt = scanner.nextLine().trim();
            if (prompt.isEmpty()) {
                System.out.println(ERROR_EMPTY_INPUT);
            }
        } while (prompt.isEmpty());
        DateQuestionCommandLineRenderer renderer = new DateQuestionCommandLineRenderer();

        return new DateQuestion(prompt, renderer);
    }

    public Response createCorrectAnswer(Scanner scanner, Question question, int questionNumber){
        System.out.println("Enter the correct answer");
        return question.respond(scanner, questionNumber);
    }
}
