import java.util.ArrayList;

public class EssayQuestionResponse extends Response{
    ArrayList<String> response;
    public EssayQuestionResponse(ArrayList<String> response, int questionNumber) {
        super(questionNumber);
        this.response = response;
    }

    @Override
    public void display() {
        int currentIndex = 0;

        while (currentIndex < response.size()) {
            char choiceLabel = (char) ('A' + currentIndex);
            System.out.println(choiceLabel + ")");
            System.out.println(response.get(currentIndex));
            currentIndex++;
        }
    }

    @Override
    public Boolean isEqual(Response response) {
        if (response instanceof EssayQuestionResponse){
            EssayQuestionResponse correctAnswer = (EssayQuestionResponse) response;
            return correctAnswer.getResponse().equals(this.getResponse());
        } else {
            return false;
        }
    }

    public ArrayList<String> getResponse(){
        return this.response;
    }
    public void setResponse(ArrayList<String> response){
        this.response=response;
    }

}
