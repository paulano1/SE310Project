import java.io.Serializable;
import java.util.ArrayList;

public class SurveyResponses implements Serializable {
    private static final long serialVersionUID = 1L;
    ArrayList<Response> userResponses;
    String surveyFileName;

    public SurveyResponses(ArrayList<Response> responses, String surveyFileName){
        userResponses = responses;
        this.surveyFileName = surveyFileName;
    }

    private Boolean checkResponseLoaded(){
        if (userResponses == null){
            System.out.println("Responses are not loaded");
            return false;
        }
        return true;
    }
    public void displayResponses(){
        if (!checkResponseLoaded()){
            return;
        }
        for (Response element : userResponses) {
            element.display();
        }
    }

    public void setUserResponses(ArrayList<Response> userResponses, String surveyFileName) {
        this.userResponses = userResponses;
        this.surveyFileName = surveyFileName;
    }

    public void setSurveyFileName(String surveyFileName) {
        this.surveyFileName = surveyFileName;
    }

    public ArrayList<Response> getUserResponses() {
        return userResponses;
    }
    public String getSurveyFileName() {
        return surveyFileName;
    }

    public void modifyByIndex(int questionNumber, Response response) {
        if (!checkResponseLoaded()){
            return;
        }
        for (int i = 0; i < userResponses.size(); i++) {
            Response currentResponse = userResponses.get(i);
            if (currentResponse.getQuestionNumber() == questionNumber) {
                userResponses.set(i, response);
                return;
            }
        }
        System.out.println("Response not found for question number: " + questionNumber);
    }

    public int getSize() {
        return userResponses.size();
    }

    public Response getByIndex(int i) {
        return userResponses.get(i);
    }
}
