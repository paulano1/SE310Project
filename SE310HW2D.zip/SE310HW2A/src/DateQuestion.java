import java.time.LocalDate;
import java.util.Scanner;

public class DateQuestion extends Question{

    LocalDate response;
    DateQuestionCommandLineRenderer renderer;

    public DateQuestion(String prompt, DateQuestionCommandLineRenderer renderer) {
        super(prompt, "dateQuestion");
        this.renderer = renderer;
    }

    @Override
    public void displayPrompt() {
        renderer.displayQuestion(prompt);
    }

    @Override
    public void displayResponse() {
        renderer.displayResponse(response);
    }

    @Override
    public Response respond(Scanner scanner, int questionNumber) {
        LocalDate tempResponse = renderer.getResponse(prompt, scanner);
        return new DateQuestionResponse(tempResponse, questionNumber);
    }

    @Override
    public void modify(Scanner scanner) {
        prompt = renderer.modifyQuestion(prompt, scanner);
    }
}
