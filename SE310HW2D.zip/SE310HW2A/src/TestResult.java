import java.util.ArrayList;

public class TestResult {
    private Test test;
    private double weightPerQuestion;
    private double total;

    private int essayQuestions;

    public TestResult(Test test){
        this.test = test;
        weightPerQuestion = 100.00/(double)test.getSurvey().size();
        this.total = 0.0;
    }

    public void grade(SurveyResponses surveyResponses){

        for (int i = 0; i < surveyResponses.getSize(); i++) {
            Question question = test.getSurvey().get(i);
            if (!question.questionType.equalsIgnoreCase("essay")){
                Response correctAnswer = test.getCorrectAnswer().getByIndex(i);
                Response userResponse = surveyResponses.getUserResponses().get(i);
                if (correctAnswer.isEqual(userResponse)){
                    this.total += weightPerQuestion;
                }
            } else {
                essayQuestions += 1;
            }
        }
    }

    public void displayResult(){
        double autoGradedScore = 100.0 - (essayQuestions * weightPerQuestion);
        System.out.println("You received a " + String.format("%.2f", total) + " on the test. The test was worth 100 points, but only " +
                String.format("%.2f", autoGradedScore) + " of those points could be auto graded because there were " +
                essayQuestions + " essay question.");
    }


}
