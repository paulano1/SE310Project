import java.util.Scanner;
import java.util.*;

public class MatchingQuestionFactory implements QuestionFactory<MatchingQuestion> {
    private static final String SEPARATOR = "--------------------------";
    private static final String OPENING = "-- Matching Question --";
    private static final String PROMPT_INSTRUCTION = "Enter the question prompt (cannot be empty):";
    private static final String MATCHING_KEY_INSTRUCTION = "Enter a key (or 'done' to finish):";
    private static final String MATCHING_VALUE_INSTRUCTION = "Now enter the matching value:";
    private static final String ERROR_EMPTY_INPUT = "Input cannot be empty. Please try again.";
    private static final String DONE_KEYWORD = "done";

    MatchingQuestionCommandLineRenderer renderer = new MatchingQuestionCommandLineRenderer();

    @Override
    public MatchingQuestion createQuestion(Scanner scanner) {
        System.out.println(OPENING);

        // Prompt for the question prompt
        String prompt;
        do {
            System.out.println(PROMPT_INSTRUCTION);
            prompt = scanner.nextLine().trim();
            if (prompt.isEmpty()) {
                System.out.println(ERROR_EMPTY_INPUT);
            }
        } while (prompt.isEmpty());

        // Prompt for keys and values
        ArrayList<String> keys = new ArrayList<>();
        ArrayList<String> values = new ArrayList<>();
        String inputKey, inputValue;
        System.out.println(SEPARATOR);
        while (true) {
            System.out.println(MATCHING_KEY_INSTRUCTION);
            inputKey = scanner.nextLine().trim();
            if (DONE_KEYWORD.equalsIgnoreCase(inputKey)) {
                break;
            }
            if (inputKey.isEmpty()) {
                System.out.println(ERROR_EMPTY_INPUT);
                continue;
            }

            while (true) {
                System.out.println(MATCHING_VALUE_INSTRUCTION);
                inputValue = scanner.nextLine().trim();
                if (!inputValue.isEmpty()) {
                    break;
                }
                System.out.println(ERROR_EMPTY_INPUT);
            }

            keys.add(inputKey);
            values.add(inputValue);
        }

        return new MatchingQuestion(prompt, keys, values, renderer);
    }

    public Response createCorrectAnswer(Scanner scanner, Question question, int questionNumber){
        System.out.println("Enter the correct answer");
        return question.respond(scanner, questionNumber);
    }
}
