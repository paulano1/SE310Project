import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class Survey implements Serializable {
    protected ArrayList<Question> questions;
    protected String fileName;
    public Survey(){
        questions = null;
    }

    public void setSurvey(ArrayList<Question> questions){
        this.questions = questions;
    }
    public ArrayList<Question> getSurvey(){
        return questions;
    }
    public void setCurrentFileName(String fileName){
        this.fileName = fileName;
    }
    public String getCurrentFileName(){
        return fileName;
    }
    public void displayQuestions() {
        if (questions == null){
            System.out.println("Survey is not loaded");
        } else {
            for (Question q : questions) {
                q.displayPrompt();
            }
        }
    }

    public SurveyResponses respond(Scanner scanner) {
        ArrayList<Response> tempResponses = new ArrayList<>();
        int questionNumber = 1;
        for (Question q : questions) {
            q.displayPrompt();
            Response currentResponse = q.respond(scanner, questionNumber);
            questionNumber += 1;
            tempResponses.add(currentResponse);
        }

        return new SurveyResponses(tempResponses, fileName);
    }


}