import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MultipleChoiceQuestionFactory implements QuestionFactory<MultipleChoiceQuestion> {
    private static final String SEPARATOR = "--------------------------";
    private static final String OPENING = "-- Multiple choice Question --";
    private static final String INSTRUCTION = "Enter choice (or type 'done' to finish):";
    private static final String DONE_KEYWORD = "done";
    MultipleChoiceQuestionCommandLineRenderer renderer = new MultipleChoiceQuestionCommandLineRenderer();

    @Override
    public MultipleChoiceQuestion createQuestion(Scanner scanner) {
        String input;
        ArrayList<String> choices = new ArrayList<>();

        System.out.println(OPENING);
        String prompt;
        while (true) {

                System.out.println("Enter your prompt");
                prompt = scanner.nextLine().trim();

                if (prompt.isEmpty()) {
                    System.out.println("Prompt can't be empty");
                } else {
                    break;
                }
        }
        System.out.println(SEPARATOR);
        int numberOfChoices;

        while (true) {
            try {
                System.out.println("Enter the number of choices");
                numberOfChoices = scanner.nextInt();

                if (numberOfChoices <= 0) {
                    System.out.println("The number of choices must be positive. Please try again.");
                } else {
                    break;
                }
            } catch (InputMismatchException e) {
                System.out.println("That's not an integer. Please enter a valid integer.");
            } finally {
                scanner.nextLine();
            }
        }

        System.out.println("Now enter the choices.");

        for (int i = 0; i < numberOfChoices; i++) {
                System.out.println("Enter choice #" + (i + 1) + ":");
                input = scanner.nextLine().trim();
                if (!input.isEmpty()) {
                    choices.add(input);
                } else {
                    System.out.println("Choice cannot be empty. Please enter a valid choice.");
                    i--;
                }
            }

        return new MultipleChoiceQuestion(prompt, choices, numberOfChoices, renderer);
    }
    public Response createCorrectAnswer(Scanner scanner, Question multipleChoiceQuestion, int questionNumber){
        System.out.println("Enter the correct answer");
        return multipleChoiceQuestion.respond(scanner, questionNumber);
    }
}
