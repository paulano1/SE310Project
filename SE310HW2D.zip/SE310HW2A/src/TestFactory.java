import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TestFactory extends SurveyFactory{
    public static final String TEST_PREFIX = "test";
    String testDirectory = "tests";
    public static final String CORRECT_ANSWER_PREFIX = "answers";
    public TestFactory(Scanner scanner) {
        super(scanner);
    }

    public void createTest(Test test) {
        if (surveyNotSaved(test)){
            if (!continueQuestion(scanner)){
                return;
            }
        }
        test.setCurrentFileName(null);

        ArrayList<Question> questions = new ArrayList<>();
        ArrayList<Response> correctAnswers = new ArrayList<>();
        int option = 0;
        int questionNumber = 1;
        do {
            createQuestionMenu();
            try {
                option = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
                continue;
            }
            switch (option) {
                case 1:
                    Question trueFalseQuestion = trueFalseQuestionFactory.createQuestion(scanner);
                    correctAnswers.add(trueFalseQuestionFactory.createCorrectAnswer(scanner, trueFalseQuestion, questionNumber));
                    questions.add(trueFalseQuestion);
                    questionNumber +=1;
                    break;
                case 2:
                    Question multipleChoiceQuestion = multipleChoiceQuestionFactory.createQuestion(scanner);
                    correctAnswers.add(multipleChoiceQuestionFactory.createCorrectAnswer(scanner, multipleChoiceQuestion, questionNumber));
                    questions.add(multipleChoiceQuestion);
                    questionNumber +=1;
                    break;
                case 3:
                    Question shortAnswerQuestion = shortAnswerQuestionFactory.createQuestion(scanner);
                    correctAnswers.add(shortAnswerQuestionFactory.createCorrectAnswer(scanner, shortAnswerQuestion, questionNumber));
                    questions.add(shortAnswerQuestion);
                    questionNumber +=1;
                    break;
                case 4:
                    Question essayQuestion = essayQuestionFactory.createQuestion(scanner);
                    correctAnswers.add(essayQuestionFactory.createCorrectAnswer(scanner, essayQuestion, questionNumber));
                    questions.add(essayQuestion);
                    questionNumber +=1;
                    break;
                case 5:
                    Question dateQuestion = dateQuestionFactory.createQuestion(scanner);
                    correctAnswers.add(dateQuestionFactory.createCorrectAnswer(scanner, dateQuestion, questionNumber));
                    questions.add(dateQuestion);
                    questionNumber +=1;
                    break;
                case 6:
                    Question matchingQuestion = matchingQuestionFactory.createQuestion(scanner);
                    correctAnswers.add(matchingQuestionFactory.createCorrectAnswer(scanner, matchingQuestion, questionNumber));
                    questions.add(matchingQuestion);
                    questionNumber +=1;
                    break;
                case 7:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (option != 7);

        if (!questions.isEmpty()) {
            test.setTest(questions, correctAnswers);
        } else {
            test.setSurvey(null);
            test.setCurrentFileName(null);
        }
    }

    public void displayTestWithoutAnswers(Test test) {
        displayQuestions(test);
    }

    public void displayTest(Test test) {
        test.displayTest();
    }

    public void saveTest(Test test) {
        ArrayList<Question> questions = test.getSurvey();
        TestCorrectAnswers testCorrectAnswers = test.getCorrectAnswer();
        String pathName = fileManager.saveQuestionnaire(questions, testDirectory, TEST_PREFIX);
        test.setCurrentFileName(pathName);
        fileManager.saveCorrectAnswer(testCorrectAnswers, pathName, CORRECT_ANSWER_PREFIX);
    }

    public void loadTest(Test test) {
        loadExistingSurvey(test, testDirectory, TEST_PREFIX);
        test.setCorrectAnswer(fileManager.loadTestCorrectAnswers(test.getCurrentFileName(), CORRECT_ANSWER_PREFIX));
    }

    public void takeTest(Scanner scanner, Test test) {
        takeSurvey(test, scanner, testDirectory, TEST_PREFIX);
    }

    private boolean confirmModification(){
        while (true){
            System.out.println("Do you want to modify this? (Enter Y or N) ");
            String response = scanner.nextLine().trim().toUpperCase();
            if ("y".equalsIgnoreCase(response)){
                return true;
            } else if ("n".equalsIgnoreCase(response)) {
                return false;
            }
            System.out.println("Invalid input. Please enter 'Y' for Yes or 'N' for No.");
        }
    }
    public void modifyTest(Scanner scanner, Test test) {
        if (test.getSurvey() == null || test.getSurvey().isEmpty()) {
            System.out.println("Please load a survey to modify.");
            return;
        }

        ArrayList<Question> questions = test.getSurvey();
        TestCorrectAnswers testCorrectAnswers = test.getCorrectAnswer();
        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            q.displayPrompt();
            if(confirmModification()){
                q.modify(scanner);
            }
            Response response = testCorrectAnswers.getUserResponses().get(i);
            System.out.println("----Correct Answer---");
            response.display();
            if (confirmModification()){
                System.out.println("Enter new correct answer");
                Response newResponse = q.respond(scanner, response.getQuestionNumber());
                testCorrectAnswers.getUserResponses().set(i,newResponse);
            }
        }
        test.setSurvey(questions);
        fileManager.saveModifiedTest(test, testCorrectAnswers);
    }

    public void grade(Test test) {
        System.out.println("Choose a test:");
        SurveyResponses userResponse = null;
        loadTest(test);
        List<String> listOfResponses = fileManager.listResponses(test.getCurrentFileName(), RESPONSE_PREFIX);
        if (listOfResponses == null){
            System.out.println("No responses available to grade");
            return;
        }
        System.out.println("--- Available Responses ---");
        int i = 0;
        for (String path:
             listOfResponses) {
            System.out.println(i+1 + ") " +path.split("\\\\")[1] + " -> " + path.split("\\\\")[3]);
            i+=1;
        }
        int fileChoice = -1;
        boolean validChoice = false;

        while (!validChoice) {
            System.out.print("Enter the number of the Response you want to grade: ");

            try {
                fileChoice = Integer.parseInt(scanner.nextLine());
                if (fileChoice >= 1 && fileChoice <= listOfResponses.size()) {
                    validChoice = true;
                } else {
                    System.out.println("Invalid choice. Please select a number from the list.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }

        String selectedFile = listOfResponses.get(fileChoice - 1);
        try {
            userResponse = fileManager.loadResponse(selectedFile);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading the survey: " + e.getMessage());
        }
        assert userResponse != null;
        TestResult testResult = new TestResult(test);
        testResult.grade(userResponse);
        testResult.displayResult();
    }
}
