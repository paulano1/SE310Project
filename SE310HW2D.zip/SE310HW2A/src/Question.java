import java.io.Serializable;
import java.util.Scanner;

public abstract class Question implements Serializable {
    String prompt;
    private static final long serialVersionUID = 1L;
    String questionType;
    public Question(String prompt, String questionType){
        this.prompt = prompt;
        this.questionType = questionType;

    }
    public void updatePrompt(String prompt){
        this.prompt = prompt;
    }

    public abstract void displayPrompt();

    public abstract void displayResponse();
    public abstract Response respond(Scanner scanner, int questionNumber);

    public abstract void  modify(Scanner scanner);

}
