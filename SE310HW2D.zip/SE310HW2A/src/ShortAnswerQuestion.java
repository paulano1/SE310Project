import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ShortAnswerQuestion extends Question{
    List<String> responses;
    Integer numberOfResponses;
    ShortAnswerQuestionCommandLineRenderer renderer;
    public ShortAnswerQuestion(String prompt, Integer numberOfResponses, ShortAnswerQuestionCommandLineRenderer renderer) {
        super(prompt, "shortAnswer");
        this.responses = new ArrayList<>(numberOfResponses);
        this.numberOfResponses = numberOfResponses;
        this.renderer = renderer;
    }
    public ShortAnswerQuestion(String prompt, Integer numberOfResponses, String questionType, ShortAnswerQuestionCommandLineRenderer renderer) {
        super(prompt, questionType);
        this.responses = new ArrayList<>(numberOfResponses);
        this.numberOfResponses = numberOfResponses;
        this.renderer = renderer;

    }

    @Override
    public void displayPrompt() {
        renderer.displayQuestion(prompt);
    }

    @Override
    public void displayResponse() {
        renderer.displayResponse(responses);
    }

    @Override
    public Response respond(Scanner scanner, int questionNumber) {
        List<String> tempResponses = renderer.getResponse(prompt, numberOfResponses, scanner);
        return new ShortAnswerResponse((ArrayList<String>) tempResponses, questionNumber);
    }

    @Override
    public void modify(Scanner scanner) {
        prompt = renderer.modifyQuestion(prompt, scanner);
        numberOfResponses = renderer.modifyNumberOfResponses(numberOfResponses, scanner);
    }
}
