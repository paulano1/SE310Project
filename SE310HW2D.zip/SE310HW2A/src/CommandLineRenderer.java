import javax.management.AttributeNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public interface CommandLineRenderer<T,V> {
    abstract void displayQuestion(V prompt);
    abstract void displayResponse(T response);
    abstract T getResponse(V prompt, Scanner scanner);
    abstract V modifyQuestion(V prompt, Scanner scanner);
}