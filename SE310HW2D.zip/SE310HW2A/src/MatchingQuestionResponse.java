import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MatchingQuestionResponse extends Response {
    ArrayList<String>  response;


    public MatchingQuestionResponse(ArrayList<String>  response, int questionNumber) {
        super(questionNumber);
        this.response = response;
    }

    public ArrayList<String> getResponse() {
        return response;
    }

    public void setResponse(ArrayList<String>  response) {
        this.response = response;
    }

    @Override
    public void display() {
        for (String resp:
             response) {
            System.out.println(resp);
        }
    }

    @Override
    public Boolean isEqual(Response response) {
        if (response instanceof MatchingQuestionResponse){
            MatchingQuestionResponse correctAnswer = (MatchingQuestionResponse) response;
            return correctAnswer.getResponse().equals(this.getResponse());
        } else {
            return false;
        }
    }

}
