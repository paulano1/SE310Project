import java.util.ArrayList;

public class TestCorrectAnswers extends SurveyResponses{
    public TestCorrectAnswers(ArrayList<Response> responses, String surveyFileName) {
        super(responses, surveyFileName);
    }

}
