import java.util.*;

public class MatchingQuestion extends Question{
    ArrayList<String> matchingPromptKey;
    ArrayList<String> matchingPromptValue;
    ArrayList<String> response;
    MatchingQuestionCommandLineRenderer renderer;
    public MatchingQuestion(String prompt, ArrayList<String> matchingPromptKey, ArrayList<String> matchingPromptValue,
                            MatchingQuestionCommandLineRenderer renderer
                            ) {
        super(prompt, "matching");
        this.matchingPromptKey = matchingPromptKey;
        this.matchingPromptValue = matchingPromptValue;
        this.renderer = renderer;
    }

    @Override
    public void displayPrompt() {
        renderer.displayQuestion(this.rendererDTO());
    }

    @Override
    public void displayResponse() {
            renderer.displayResponse(response);
    }

    @Override
    public Response respond(Scanner scanner, int questionNumber) {
        ArrayList<String> tempResponse = renderer.getResponse(this.rendererDTO(), scanner);
        return new MatchingQuestionResponse(tempResponse, questionNumber);
    }

    public void modify(Scanner scanner){
        HashMap<String, ArrayList<String>> temp = renderer.modifyQuestion(rendererDTO(), scanner);
        matchingPromptValue = temp.get("values");
        matchingPromptKey = temp.get("keys");
        prompt = temp.get("question").get(0);
    }

    private HashMap<String, ArrayList<String>> rendererDTO(){
        HashMap<String, ArrayList<String>> temp = new HashMap<>();
        temp.put("question", new ArrayList<>(Collections.singletonList(prompt)));
        temp.put("keys", matchingPromptKey);
        temp.put("values",matchingPromptValue);
        return temp;
    }
}
