import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EssayQuestion extends ShortAnswerQuestion{
    public EssayQuestion(String prompt, Integer numberOfResponses, ShortAnswerQuestionCommandLineRenderer renderer) {
        super(prompt, numberOfResponses, "essay", renderer);
    }

    @Override
    public Response respond(Scanner scanner, int questionNumber) {
        List<String> tempResponses = renderer.getResponse(prompt, numberOfResponses, scanner);
        return new EssayQuestionResponse((ArrayList<String>) tempResponses, questionNumber);
    }
}
