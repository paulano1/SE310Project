import java.util.ArrayList;
import java.io.*;
import java.util.List;

public class FileManager {
    private static final FileManager instance = new FileManager();
    public static final String FILE_EXTENSION = ".ser";

    private FileManager() {
        if (instance != null) {
            throw new IllegalStateException("Already initialized.");
        }
    }

    public static FileManager getInstance() {
        return instance;
    }

    public ArrayList<Question> loadQuestions(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            return (ArrayList<Question>) in.readObject();
        } catch (Exception e){
            System.out.println(e.getMessage());
            return null;
        }
    }

    public List<String> listSurveyFiles(String directoryPath, String filePrefix) {
        System.out.println("Survey list" + directoryPath);
        File directory = new File(directoryPath);
        File[] surveyDirectories = directory.listFiles(File::isDirectory);

        List<String> surveyFiles = new ArrayList<>();
        if (surveyDirectories != null) {
            for (File surveyDir : surveyDirectories) {
                File surveyFile = new File(surveyDir, filePrefix + FILE_EXTENSION);
                if (surveyFile.exists()) {
                    surveyFiles.add(surveyFile.getPath());
                }
            }
        }

        return surveyFiles.isEmpty() ? null : surveyFiles;
    }



    public void saveObjectStaticPath(ArrayList<Question> object, String fullPath) {
        if (fullPath == null) {
            return;
        }
        saveObjectToFile(object, fullPath);
    }
    private void saveObjectToFile(Object object, String fullPath) {
        File file = new File(fullPath);
        if (file.exists() && !file.delete()) {
            System.err.println("Failed to delete the old file before saving the new one: " + file.getAbsolutePath());
            return;
        }
        File directory = file.getParentFile();
        if (!directory.exists()) {
            if (!directory.mkdirs()) {
                System.err.println("Failed to create directories: " + directory.getAbsolutePath());
                return;
            }
        }

        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
            out.writeObject(object);
        } catch (IOException e) {
            System.out.println("Error is saving file, please try again");
        }
    }

    private String getNextAvailableFileName(String baseDirectoryPath, String filePrefix, String fileExtension) {
        File baseDirectory = new File(baseDirectoryPath);

        if (!baseDirectory.exists() && !baseDirectory.mkdirs()) {
            System.err.println("Failed to create base directory: " + baseDirectoryPath);
            return null;
        }

        File[] existingFiles = baseDirectory.listFiles((dir, name) -> name.startsWith(filePrefix) && name.toLowerCase().endsWith(fileExtension));

        int highestNumber = 0;
        if (existingFiles != null) {
            for (File file : existingFiles) {
                String name = file.getName();
                name = name.replace(filePrefix, "").replace(fileExtension, "");
                try {
                    int number = Integer.parseInt(name);
                    if (number > highestNumber) {
                        highestNumber = number;
                    }
                } catch (NumberFormatException e) {
                    System.out.println(e.getMessage());
                }
            }
        }

        return filePrefix + (highestNumber + 1) + fileExtension;
    }


    public boolean saveQuestionnaireResponse(SurveyResponses responses, String filePrefix) {
        if (responses == null) {
            System.err.println("Error: The "+ filePrefix + " object is null.");
            return false;
        }

        if (responses.getSurveyFileName() == null) {
            System.err.println("Error: The survey file name in "+ filePrefix + " is null.");
            return false;
        }

        if (responses.getUserResponses() == null) {
            System.err.println("Error: The user responses in "+ filePrefix + " are null.");
            return false;
        }
        File surveyFile = new File(responses.getSurveyFileName());
        String surveyDirectory = surveyFile.getParent();

        if (surveyDirectory == null) {
            System.err.println("Error: Invalid survey file path.");
            return false;
        }

        String responseDirectory = surveyDirectory + File.separator + filePrefix;

        try {
            String filename = getNextAvailableFileName(responseDirectory, filePrefix, ".ser");
            if (filename == null) {
                System.err.println("Failed to save survey"+ filePrefix );
                return false;
            }

            String fullPath = responseDirectory + File.separator + filename;
            saveObjectToFile(responses, fullPath);
            System.out.println("Survey responses saved successfully to: " + fullPath);
            return true;
        } catch (Exception e) {
            System.err.println("An error occurred while saving survey responses: " + e.getMessage());
            return false;
        }
    }



    public String saveQuestionnaire(ArrayList<Question> questions, String surveyDirectory, String filePrefix) {
        if (questions == null || questions.isEmpty()) {
            System.err.println("No questions to save.");
            return null;
        }

        String surveyName = getNextAvailableFileName(surveyDirectory, filePrefix, "");
        if (surveyName == null) {
            System.err.println("Failed to generate a unique survey name.");
            return null;
        }

        String surveyPath = surveyDirectory + File.separator + surveyName;
        String surveyFilePath = surveyPath + File.separator + filePrefix + FILE_EXTENSION;

        try {
            File surveyDir = new File(surveyPath);
            if (!surveyDir.exists() && !surveyDir.mkdirs()) {
                System.err.println("Failed to create survey directory: " + surveyPath);
                return null;
            }

            saveObjectToFile(questions, surveyFilePath);
            System.out.println("Survey saved successfully to: " + surveyFilePath);
            return surveyFilePath;
        } catch (Exception e) {
            System.err.println("An error occurred while saving the survey: " + e.getMessage());
            return null;
        }
    }

    public SurveyResponses loadResponse(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            Object obj = in.readObject();
            if (obj instanceof SurveyResponses) {
                return (SurveyResponses) obj;
            } else {
                throw new ClassCastException("Object is not an instance of SurveyResponses. Object class: " + obj.getClass().getName());
            }
        }
    }




    public ArrayList<SurveyResponses> getAllResponses(String fullPath) {

        File surveyFile = new File(fullPath);
        String surveyDirectoryPath = surveyFile.getParent() + File.separator + "response";
        File responseDirectory = new File(surveyDirectoryPath);
        if (!responseDirectory.exists() || !responseDirectory.isDirectory()) {
            System.err.println("Invalid directory path: " + responseDirectory);
            return null;
        }

        File[] files = responseDirectory.listFiles();
        ArrayList<SurveyResponses> allResponses = new ArrayList<>();
        if (files == null){
            System.out.println("No responses");
            return null;
        }
        for (File file : files) {
            if (file.isFile() && file.getName().endsWith(".ser")) {
                try {
                   SurveyResponses tempResp = loadResponse(file.getPath());
                   allResponses.add(tempResp);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    System.err.println("Error reading file: " + file.getName());
                }
            }
        }

        return allResponses;
    }

    public void saveCorrectAnswer(TestCorrectAnswers testCorrectAnswers, String testPath, String correctAnswerPrefix) {
        File testFile = new File(testPath);
        String correctAnswerPath = testFile.getParent() + File.separator + correctAnswerPrefix + FILE_EXTENSION;
        testCorrectAnswers.setSurveyFileName(correctAnswerPath);
        saveObjectToFile(testCorrectAnswers, correctAnswerPath);
    }

    public TestCorrectAnswers loadTestCorrectAnswers(String currentFileName, String correctAnswerPrefix) {
        File testFile = new File(currentFileName);
        String correctAnswerPath = testFile.getParent() + File.separator + correctAnswerPrefix + FILE_EXTENSION;

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(correctAnswerPath))) {
            return (TestCorrectAnswers) in.readObject();
        } catch (ClassNotFoundException | IOException e) {
            System.out.println("could not load correct answers");
        }
       return null;
    }

    public void saveModifiedTest(Test test, TestCorrectAnswers testCorrectAnswers) {
        saveObjectToFile(test.getSurvey(), test.getCurrentFileName());
        saveObjectToFile(testCorrectAnswers, testCorrectAnswers.getSurveyFileName());
    }

    public List<String> listResponses(String currentFileName, String responsePrefix) {
        File testFile = new File(currentFileName);
        String responseDirectory = testFile.getParent() + File.separator + responsePrefix;

        File dir = new File(responseDirectory);
        FilenameFilter filter = (file, name) -> name.endsWith(".ser");
        File[] files = dir.listFiles(filter);

        List<String> responseFiles = new ArrayList<>();
        if (files != null) {
            for (File file : files) {
                responseFiles.add(file.getPath());
            }
        }
        return responseFiles;
    }
}