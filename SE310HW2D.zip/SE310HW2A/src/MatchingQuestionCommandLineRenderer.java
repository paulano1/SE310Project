import java.io.Serializable;
import java.util.*;

public class MatchingQuestionCommandLineRenderer implements CommandLineRenderer<ArrayList<String>, HashMap<String, ArrayList<String>>>, Serializable {
    private static final long serialVersionUID = 1L;
    private static final String SEPARATOR = "--------------------------";
    private static final String OPENING = "-----Matching Question----";

    public void displayQuestion(HashMap<String, ArrayList<String>> prompt) {
        System.out.println(OPENING);

        // Retrieve and remove the main question prompt
        ArrayList<String> questionPrompt = prompt.get("question");
        if (questionPrompt == null) {
            System.out.println("Prompt not found");
        } else {
            // Display the main question prompt
            System.out.println(questionPrompt.get(0));
            char leftSide = 'A';
            int rightSide = 1;
            ArrayList<String> keys = prompt.get("keys");
            ArrayList<String> values = prompt.get("values");

            for (int i = 0; i < keys.size(); i++) {
                System.out.printf("%-2s %-10s %-2s %s%n", leftSide + ")", keys.get(i), rightSide + ")", values.get(i));
                leftSide++;
                rightSide++;
            }
        }
        System.out.println(SEPARATOR);
    }

    public void displayResponse(ArrayList<String> response) {
        System.out.println(SEPARATOR);
        for (String resp:
             response) {
            System.out.println(resp);
        }
        System.out.println(SEPARATOR);

    }

    public ArrayList<String> getResponse(HashMap<String, ArrayList<String>> matchingPrompt, Scanner scanner) {
        HashMap<String, String> response = new HashMap<>();
        HashSet<String> usedKeys = new HashSet<>(); // To keep track of keys that have already been used
        HashSet<String> usedValues = new HashSet<>(); // To keep track of values that have already been used
        ArrayList<String> keys = matchingPrompt.get("keys");
        ArrayList<String> values = matchingPrompt.get("values");

        int numberOfMatchesNeeded = keys.size();
        System.out.println("Enter your matches one by one (e.g., A1):");

        ArrayList<String> userInputs = new ArrayList<>();

        while (response.size() < numberOfMatchesNeeded) {
            String userInput = scanner.nextLine().toUpperCase().trim();
            if (userInput.length() == 2) {
                char keyChar = userInput.charAt(0);
                char valueChar = userInput.charAt(1);

                int keyIndex = keyChar - 'A';
                int valueIndex = Character.getNumericValue(valueChar) - 1;

                if (keyIndex >= 0 && keyIndex < keys.size() && valueIndex >= 0 && valueIndex < values.size()) {
                    String key = keys.get(keyIndex);
                    String value = values.get(valueIndex);

                    if (!usedKeys.contains(key) && !usedValues.contains(value)) {
                        response.put(key, value);
                        usedKeys.add(key); // Mark the key as used
                        usedValues.add(value); // Mark the value as used
                        userInputs.add(userInput);
                    } else {
                        if (usedKeys.contains(key)) {
                            System.out.println("This key has already been used: " + key);
                        }
                        if (usedValues.contains(value)) {
                            System.out.println("This value has already been used: " + value);
                        }
                    }
                } else {
                    System.out.println("Invalid input: " + userInput);
                }
            } else {
                System.out.println("Invalid format: " + userInput);
            }
            if (response.size() < numberOfMatchesNeeded) {
                System.out.println("Please enter the next match:");
            }
        }
        return userInputs;
    }


    public HashMap<String, ArrayList<String>> modifyQuestion(HashMap<String, ArrayList<String>> prompt, Scanner scanner) {
        while (true) {
            displayQuestion(prompt);
            System.out.println("What do you want to modify?");
            System.out.println("1. Prompt");
            System.out.println("2. Keys");
            System.out.println("3. Values");
            System.out.println("4. Done");

            String input = scanner.nextLine().trim();
            int choice = input.isEmpty() ? -1 : input.charAt(0) - '0'; // Convert first char to int choice

            if (choice < 1 || choice > 4) {
                System.out.println("Invalid choice. Please select an option between 1 and 4.");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.println("Enter your modified prompt:");
                    String newPrompt = scanner.nextLine();
                    prompt.put("question", new ArrayList<>(Collections.singletonList(newPrompt)));
                    break;
                case 2:
                    modifyListElement(prompt.get("keys"), "key", scanner);
                    break;
                case 3:
                    modifyListElement(prompt.get("values"), "value", scanner);
                    break;
                case 4:
                    return prompt;
            }
        }
    }

    private void modifyListElement(ArrayList<String> list, String elementType, Scanner scanner) {
        System.out.println("Which " + elementType + " do you want to modify? Enter the number:");
        for (int i = 0; i < list.size(); i++) {
            System.out.println((i + 1) + ". " + list.get(i));
        }

        try {
            int index = Integer.parseInt(scanner.nextLine()) - 1;
            if (index >= 0 && index < list.size()) {
                System.out.println("Enter the new " + elementType + ":");
                String newValue = scanner.nextLine();
                list.set(index, newValue);
            } else {
                System.out.println("Invalid " + elementType + " number.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        }
    }



}
