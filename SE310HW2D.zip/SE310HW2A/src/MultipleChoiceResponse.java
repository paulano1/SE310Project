import java.util.ArrayList;

public class MultipleChoiceResponse extends EssayQuestionResponse{
    public MultipleChoiceResponse(ArrayList<String> response, int questionNumber) {
        super(response, questionNumber);
    }
    @Override
    public Boolean isEqual(Response response) {
        if (response instanceof MultipleChoiceResponse){
            MultipleChoiceResponse correctAnswer = (MultipleChoiceResponse) response;
            return correctAnswer.getResponse().equals(this.getResponse());
        } else {
            return false;
        }
    }
}
