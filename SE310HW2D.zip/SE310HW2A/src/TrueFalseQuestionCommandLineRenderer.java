import java.io.Serializable;
import java.util.Scanner;

public class TrueFalseQuestionCommandLineRenderer implements CommandLineRenderer<Boolean, String>, Serializable {
    String separator = "--------------------------";
    private static final long serialVersionUID = 1L;

    public void displayQuestion(String prompt) {
        System.out.println("--------True or False-----");
        System.out.println("Question: " + prompt); // Print the actual question
    }


    public void displayResponse(Boolean response) {


        System.out.println(separator);
        if (response == null) {
            System.out.println("Answer: No response");
        } else {
            System.out.println("User response: " + response);
        }

    }


    public Boolean getResponse(String matchingPrompt, Scanner scanner) {
        String input;
        Boolean response = null;

        while (response == null) {
            System.out.println(separator);
            System.out.println("Please enter 'true' or 'false':");
            input = scanner.nextLine().trim();

            // Check the input and convert to Boolean
            if ("true".equalsIgnoreCase(input) || "t".equalsIgnoreCase(input)) {
                response = Boolean.TRUE;
            } else if ("false".equalsIgnoreCase(input) || "f".equalsIgnoreCase(input)) {
                response = Boolean.FALSE;
            } else {
                System.out.println("Invalid input. Only 'true' or 'false' is accepted."); // Prompt again if input is not valid
            }
        }

        return response;
    }

    public String modifyQuestion(String prompt, Scanner scanner) {
        String newPrompt = "";
        while (newPrompt.isEmpty()) {
            System.out.println("Current prompt: " + prompt);
            System.out.println("Enter a new prompt (it cannot be empty):");
            newPrompt = scanner.nextLine().trim();

            if (newPrompt.isEmpty()) {
                System.out.println("The prompt cannot be empty. Please enter a valid prompt.");
            }
        }

        return newPrompt;
    }
}
