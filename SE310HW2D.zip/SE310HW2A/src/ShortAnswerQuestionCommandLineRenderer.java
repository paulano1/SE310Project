import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ShortAnswerQuestionCommandLineRenderer implements CommandLineRenderer<List<String>, String>, Serializable {
    private static final String SEPARATOR = "--------------------------";
    private String OPENING = "--- Short Answer Question--";
    private static final long serialVersionUID = 1L;

    public ShortAnswerQuestionCommandLineRenderer(String opening){
        this.OPENING = opening;
    }

    public ShortAnswerQuestionCommandLineRenderer() {

    }

    public void setQuestionType(String opening){
        OPENING = opening;
    }
    @Override
    public void displayQuestion(String prompt) {
        System.out.println(OPENING);
        System.out.println(prompt);
        System.out.println(SEPARATOR);
    }

    @Override
    public void displayResponse(List<String> responses) {
        int currentIndex = 0;
        if (responses == null) {
            System.out.println("User response: No response");
            return;
        }
        for (String response : responses) {
            char choiceLabel = (char) ('A' + currentIndex);
            System.out.println(choiceLabel + ")" + response);
            currentIndex += 1;
        }
    }

    @Override
    public List<String> getResponse(String prompt, Scanner scanner) {
        return null;
    }

    @Override
    public String modifyQuestion(String prompt, Scanner scanner) {
        String newPrompt = "";
        while (newPrompt.isEmpty()) {
            System.out.println("Current prompt: " + prompt);
            System.out.println("Enter a new prompt (it cannot be empty):");
            newPrompt = scanner.nextLine().trim();

            if (newPrompt.isEmpty()) {
                System.out.println("The prompt cannot be empty. Please enter a valid prompt.");
            }
        }

        return newPrompt;
    }

    public Integer modifyNumberOfResponses(Integer number, Scanner scanner){
        Integer newNumber = 0;
        while (newNumber.equals(0)){
            System.out.println("Current number: "+ number);
            System.out.println("Number of Responses cannot be 0");
            newNumber = scanner.nextInt();
        }
        return newNumber;
    }
    public List<String> getResponse(String prompt, Integer numberOfResponses, Scanner scanner) {
        List<String> response = new ArrayList<>(numberOfResponses);
        int currentIndex = 0;

        while (currentIndex < numberOfResponses) {
            char choiceLabel = (char) ('A' + currentIndex);
            System.out.println(choiceLabel + ")");

            String input = scanner.nextLine().trim();
            if (input.isEmpty()) {
                System.out.println("Response cannot be empty. Please enter a valid input.");
            } else {
                response.add(input);
                currentIndex++;
            }
        }

        return response;
    }

}
