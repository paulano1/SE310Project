public class TrueFalseQuestionResponse extends Response{
    private Boolean response;

    public TrueFalseQuestionResponse(Boolean response, int questionNumber) {
        super(questionNumber);
        this.response = response;
    }

    public void setResponse(Boolean response) {
        this.response = response;
    }
    public Boolean getResponse(){
        return this.response;
    }

    @Override
    public void display() {
        System.out.println(response);
    }

    @Override
    public Boolean isEqual(Response response) {
        if (response instanceof TrueFalseQuestionResponse){
            TrueFalseQuestionResponse correctAnswer = (TrueFalseQuestionResponse) response;
            return correctAnswer.getResponse().equals(this.getResponse());
        } else {
            return false;
        }
    }

}
