import java.io.Serializable;
import java.util.Scanner;

public abstract class Response implements Serializable {
    private static final long serialVersionUID = 1L;
    int questionNumber;

    public Response(int questionNumber){
        this.questionNumber = questionNumber;
    }
    public abstract void display();
    public abstract Boolean isEqual(Response response);
    public void setQuestionNumber(int questionNumber){
        this.questionNumber = questionNumber;
    }

    public int getQuestionNumber(){
        return this.questionNumber;
    }
}
