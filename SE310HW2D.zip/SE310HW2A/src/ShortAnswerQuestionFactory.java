import java.util.Scanner;
public class ShortAnswerQuestionFactory implements QuestionFactory<ShortAnswerQuestion> {

    @Override
    public ShortAnswerQuestion createQuestion(Scanner scanner) {
        System.out.println("Please enter the prompt for the short answer question:");
        String prompt = scanner.nextLine().trim();
        while (prompt.isEmpty()) {
            System.out.println("The prompt cannot be empty. Please enter a valid prompt:");
            prompt = scanner.nextLine().trim();
        }

        Integer numberOfResponses = null;
        while (numberOfResponses == null) {
            System.out.println("Please enter the number of responses for the short answer question:");
            String numResponseStr = scanner.nextLine().trim();
            try {
                numberOfResponses = Integer.parseInt(numResponseStr);
                if (numberOfResponses < 1) {
                    System.out.println("The number of responses must be at least 1.");
                    numberOfResponses = null;
                }
            } catch (NumberFormatException e) {
                System.out.println("That's not a valid number. Please enter an integer value.");
            }
        }

        ShortAnswerQuestionCommandLineRenderer renderer = new ShortAnswerQuestionCommandLineRenderer();
        renderer.setQuestionType("---Short Answer Question--");

        return new ShortAnswerQuestion(prompt, numberOfResponses, renderer);
    }
    public Response createCorrectAnswer(Scanner scanner, Question question, int questionNumber){
        System.out.println("Enter the correct answer");
        return question.respond(scanner, questionNumber);
    }
}
