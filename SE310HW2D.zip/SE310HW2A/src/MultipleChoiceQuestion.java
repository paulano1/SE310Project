import java.util.ArrayList;
import java.util.Scanner;

public class MultipleChoiceQuestion extends Question{
    ArrayList<String> choices;
    ArrayList<String> responses;
    Integer numberOfChoices;
    MultipleChoiceQuestionCommandLineRenderer renderer;
    public MultipleChoiceQuestion(String prompt, ArrayList<String> choices, Integer numberOfChoices, MultipleChoiceQuestionCommandLineRenderer renderer) {
        super(prompt, "multipleChoice");
        this.numberOfChoices = numberOfChoices;
        this.choices = choices;
        this.renderer = renderer;
    }

    public void displayPrompt() {
        renderer.displayQuestion(multipleChoiceQuestionDTO());
    }


    public void displayResponse() {
        renderer.displayResponse(responses);

    }


    public Response respond(Scanner scanner, int questionNumber) {
        ArrayList<String> tempResponses = renderer.getResponse(choices, scanner);
        return new MultipleChoiceResponse(tempResponses, questionNumber);
    }

    @Override
    public void modify(Scanner scanner) {
        ArrayList<String> temp = renderer.modifyQuestion(multipleChoiceQuestionDTO(), scanner);
        this.prompt = temp.get(0);
        choices = new ArrayList<>(temp.subList(1, temp.size()));
    }

    private ArrayList<String> multipleChoiceQuestionDTO(){
        ArrayList<String> temp = new ArrayList<>();
        temp.add(prompt);
        temp.addAll(choices);
        return temp;
    }

    public int getNumberOfChoices() {
        return numberOfChoices;
    }
}
